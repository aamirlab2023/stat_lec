#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 17 09:02:06 2023

@author: aamir
"""

import math as m

def stdev_p(data, formula="conceptual"):
	
	xi = data
	mu = sum(data)/len(data)
	if formula == "conceptual":
		dev = []
		dev_2 = []
		for i in xi:
			dev.append(i - mu)
			dev_2.append((i - mu)**2)
		standard_deviation = m.sqrt(sum(dev_2)/len(xi))
		
		print("Score         Population Mean    Deviation     Sqrd Deviation")
		print("==========    ===============    ==========    ==============")
		for i in range(len(xi)):
			print(f'{xi[i]:<10.2f}    {mu:<15.2f}    {dev[i]:<10.2f}    {dev_2[i]:<.2f}')
		
	elif formula == "computational":
		xi_2 = []
		for i in xi:
			xi_2.append(i**2)
		sum_xi_2 = sum(xi_2)
		sum_xi = sum(xi)
		standard_deviation = m.sqrt((sum_xi_2 - (sum_xi**2/len(xi)))/len(xi))
		
		print("Score         Score Sqrd")
		print("==========    ==========")
		for i in range(len(xi)):
			print(f'{xi[i]:<10.2f}    {xi_2[i]:<.2f}')
	
	print(f'Standard Deviation = {standard_deviation:.2f} points')
		
	return 0

stdev_p([82, 77, 90, 71, 62, 68, 74, 84, 94, 88], formula="computational")