#!/usr/bin/env python3

import statistics as stat
import matplotlib.pyplot as plt

unia = [73, 103, 91, 93, 136, 108, 92, 104, 90, 78, 108, 93, 91, 78, 81, 130,
82, 86, 111, 93, 102, 111, 125, 107, 80, 90, 122, 101, 82, 115, 103, 110, 84,
115, 85, 83, 131, 90, 103, 106, 71, 69, 97, 130, 91, 62, 85, 94, 110, 85, 102,
109, 105, 97, 104, 94, 92, 83, 94, 114, 107, 94, 112, 113, 115, 106, 97, 106,
85, 99, 102, 109, 76, 94, 103, 112, 107, 101, 91, 107, 107, 110, 106, 103, 93,
110, 125, 101, 91, 119, 118, 85, 127, 141, 129, 60, 115, 80, 111, 79]

unib = [86, 91, 107, 94, 105, 107, 89, 96, 102, 96, 92, 109, 103, 106, 98, 95,
 97, 95, 109, 109, 93, 91, 92, 91, 117, 108, 89, 95, 103, 109, 110, 88, 97, 119,
 90, 99, 96, 104, 98, 95, 87, 105, 111, 87, 103, 92, 103, 107, 106, 97, 107,
108, 89, 96, 107, 107, 96, 95, 117, 97, 98, 89, 104, 99, 99, 87, 91, 105, 109,
 108, 116, 107, 90, 98, 98, 92, 119, 96, 118, 98, 97, 106, 114, 87, 107, 96, 93,
 99, 89, 94, 104,  88, 99, 97, 106, 107, 112, 97, 94, 107]

nbins = [50, 70, 85, 100, 115, 130, 145, 160]

print(stat.stdev(unia))
print(stat.stdev(unib))
print(min(unia))

fig, axs = plt.subplots(1, 2, tight_layout=True)

axs[0].hist(unia, bins=nbins, edgecolor='k')
plt.sca(axs[0])
plt.xticks(nbins, size=12, weight='bold')
plt.xlabel("IQ Scores", size=12, weight='bold')
plt.yticks(size=12, weight='bold')
plt.ylabel("Frequency", size=12, weight='bold')
plt.title("University A IQ Scores", size=14, weight='bold')

axs[1].hist(unib, bins=nbins, edgecolor='k')
plt.sca(axs[1])
plt.xticks(nbins, size=12, weight='bold')
plt.xlabel("IQ Scores", size=12, weight='bold')
plt.yticks(size=12, weight='bold')
plt.ylabel("Frequency", size=12, weight='bold')
plt.title("University B IQ Scores", size=14, weight='bold')

plt.show()
