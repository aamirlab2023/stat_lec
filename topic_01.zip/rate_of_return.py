#!/usr/bin/env python3

import matplotlib.pyplot as plt

rate_of_return = [8, 8, 9, 9, 10, 10, 10, 10, 11, 12, 12, 12, 12, 12, 12, 13,
                  13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14, 14,
                  14, 14, 14, 14, 15, 15, 15, 16, 19]

bs = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

plt.hist(rate_of_return, bins=bs, edgecolor='black')
plt.xticks(size=12, weight='bold')
plt.xlabel("Rate of Return", size=12, weight='bold')
plt.yticks(size=12, weight='bold')
plt.ylabel("Frequency", size=12, weight='bold')
plt.grid(axis='y')
plt.show()
