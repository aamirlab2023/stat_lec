#!/usr/bin/env python3


from random import randint

n = int(input("Enter the number of samples required: "))
N = int(input("Enter the populations size: "))

samples = []

while len(samples) < n:
    sample = randint(1, N)
    if sample not in samples:
        samples.append(sample)

print(samples)
