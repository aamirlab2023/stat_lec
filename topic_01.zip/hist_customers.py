#!/usr/bin/env python3

import matplotlib.pyplot as plt

n_customers = [7, 6, 6, 6, 4, 6, 2, 6, 5, 6, 6, 11, 4, 5, 7, 6, 2, 7, 1, 2, 4,
               8, 2, 6, 6, 5, 5, 3, 7, 5, 4, 6, 2, 2, 9, 7, 5, 9, 8, 5]

lowest_count = min(n_customers)
highest_count = max(n_customers)

frequency = [n_customers.count(i) for i in range(lowest_count, highest_count +
                                                 1)]
relative_frequency = [i/sum(frequency) for i in frequency]
print(relative_frequency)

plt.figure(figsize=(8, 6))
plt.bar(range(lowest_count, highest_count + 1), relative_frequency, color='b',
       width=1.0, edgecolor='k')
plt.xticks(range(lowest_count, highest_count + 1), size=12, weight='bold')
plt.yticks(size=12, weight='bold')
plt.xlabel("Number of Customers", size=12, weight='bold')
plt.ylabel("Relative Frequency", size=12, weight='bold')
plt.title("Arrival at Wendy's", size=14, weight='bold')
plt.tight_layout()
plt.show()
