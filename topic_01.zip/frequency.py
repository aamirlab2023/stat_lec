#!/usr/bin/env python3

import matplotlib.pyplot as plt

body_part = ['Back', 'Wrist', 'Elbow', 'Hip', 'Shoulder', 'Knee', 'Hand',
             'Groin', 'Neck']
frequency = [12, 2, 1, 2, 4, 5, 2, 1, 1]
relative_frequency = [i/30 for i in frequency]
relative_frequency = sorted(relative_frequency, reverse=True)

plt.figure(figsize=(8, 5))
plt.bar(body_part, relative_frequency, color='b')
plt.xticks(rotation=90, size=12, weight='bold')
plt.yticks(size=12, weight='bold')
plt.xlabel("Body Part", size=12, weight='bold')
plt.ylabel("Relative Frequency", size=12, weight='bold')
plt.title("Bar Plot", size=14, weight='bold')
plt.tight_layout()
plt.show()
